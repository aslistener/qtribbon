// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.

#pragma once

#include <uiribbon.h>

//
//  CLASS: CApplication : IUIApplication
//
//  PURPOSE: Implements interface IUIApplication that defines methods
//           required to manage Framework events.
//
//  COMMENTS:
//
//    CApplication implements the IUIApplication interface which is required for any ribbon application.
//    IUIApplication contains callbacks made by the ribbon framework to the application
//    during various updates like command creation/destruction and view state changes.
//
class CApplication
    : public IUIApplication // Applications must implement IUIApplication.
{
public:
    STDMETHOD(OnViewChanged)(UINT32 nViewID, UI_VIEWTYPE typeID,
    IUnknown* pView, UI_VIEWVERB verb, INT32 uReasonCode);

    STDMETHOD(OnCreateUICommand)(UINT32 nCmdID, UI_COMMANDTYPE typeID,
    IUICommandHandler** ppCommandHandler);

    STDMETHOD(OnDestroyUICommand)(UINT32 commandId, UI_COMMANDTYPE typeID,
    IUICommandHandler* pCommandHandler);

    static HRESULT CreateInstance(CApplication **ppHandler, HWND hwnd);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID iid, void** ppv);
    IFACEMETHODIMP_(ULONG) AddRef();
    IFACEMETHODIMP_(ULONG) Release();

private:
    CApplication()
        : m_cRef(1), m_hwnd(NULL)
    {
    }

    LONG m_cRef;
    HWND m_hwnd;
};