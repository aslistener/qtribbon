// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved

#pragma once

#include <UIRibbon.h>
#include <UIRibbonPropertyHelpers.h>
#include "Renderer.h"

extern CRenderer g_renderer;
extern IUIFramework* g_pFramework;

//
//  CLASS: CColorPickerHandler : IUICommandHandler
//
//  PURPOSE: Implements interface IUICommandHandler. 
//
//  COMMENTS:
//
//    This is a command handler used by color picker in this sample.
//    IUICommandHandler should be returned by the application during command creation.
//
class CColorPickerHandler
    : public IUICommandHandler
{
public:
    // Static method to create an instance of this object.
    static HRESULT CreateInstance(CColorPickerHandler **ppCommandHandler);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID iid, void** ppv);
    IFACEMETHODIMP_(ULONG) AddRef();
    IFACEMETHODIMP_(ULONG) Release();

    // IUICommandHandler methods.
    STDMETHOD(Execute)(UINT nCmdID,
                       UI_EXECUTIONVERB verb, 
                       const PROPERTYKEY* key,
                       const PROPVARIANT* ppropvarValue,
                       IUISimplePropertySet* pCommandExecutionProperties);

    STDMETHOD(UpdateProperty)(UINT nCmdID,
                              REFPROPERTYKEY key,
                              const PROPVARIANT* ppropvarCurrentValue,
                              PROPVARIANT* ppropvarNewValue);
private:
    CColorPickerHandler() : m_fInitialized(FALSE), m_cRef(1) { };

    ULONG m_cRef;
    BOOL m_fInitialized;
};

//
//  CLASS: CButtonHandler : IUICommandHandler
//
//  PURPOSE: Implements interface IUICommandHandler. 
//
//  COMMENTS:
//
//    This is a command handler used by button commands in this sample.
//    IUICommandHandler should be returned by the application during command creation.
//
class CButtonHandler
    : public IUICommandHandler
{
public:  
    // Static method to create an instance of this object.
    static HRESULT CreateInstance(CButtonHandler **ppCommandHandler);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID iid, void** ppv);
    IFACEMETHODIMP_(ULONG) AddRef();
    IFACEMETHODIMP_(ULONG) Release();

    // IUICommandHandler methods.
    STDMETHOD(Execute)(UINT nCmdID,
                       UI_EXECUTIONVERB verb, 
                       const PROPERTYKEY* key,
                       const PROPVARIANT* ppropvarValue,
                       IUISimplePropertySet* pCommandExecutionProperties);

    STDMETHOD(UpdateProperty)(UINT nCmdID,
                              REFPROPERTYKEY key,
                              const PROPVARIANT* ppropvarCurrentValue,
                              PROPVARIANT* ppropvarNewValue);
private:
    CButtonHandler() : m_cRef(1) { };

    ULONG m_cRef;
};