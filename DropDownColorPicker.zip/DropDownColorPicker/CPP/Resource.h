// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved

// Used by DropDownColorPicker.rc.
//

#define IDS_APP_TITLE            103
#define IDS_APP_CLASS            104
#define IDI_RIBBONAPP            107
#define IDI_SMALL                108
