// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved

#include <UIRibbon.h>
#include <UIRibbonPropertyHelpers.h>
#include "ribbonres.h"
#include "CommandHandler.h"

class CApplication
    : public IUIApplication
{
public:
    // Static method to create an instance of this object.
    static HRESULT CreateInstance(IUIApplication** ppApplication, HWND hwnd);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID iid, void** ppv);
    IFACEMETHODIMP_(ULONG) AddRef();
    IFACEMETHODIMP_(ULONG) Release();

    // IUIApplication methods.
    STDMETHOD(OnViewChanged)(UINT32 nViewID, UI_VIEWTYPE typeID, IUnknown* pView, UI_VIEWVERB verb, INT32 uReasonCode);
    STDMETHOD(OnCreateUICommand)(UINT32 nCmdID, UI_COMMANDTYPE typeID, IUICommandHandler** ppCommandHandler);
    STDMETHOD(OnDestroyUICommand)(UINT32 commandId, UI_COMMANDTYPE typeID, IUICommandHandler* pCommandHandler);

private:    
    CApplication()
        : m_cRef(1)
        , m_pButtonHandler(NULL)
        , m_pColorPickerHandler(NULL)
    {
    };

    ~CApplication()
    {
        if (m_pButtonHandler != NULL)
        {
            m_pButtonHandler->Release();
        }
        if (m_pColorPickerHandler != NULL)
        {
            m_pColorPickerHandler->Release();
        }
    };

    HWND m_hWnd;    // Window handler.
    ULONG m_cRef;
    CButtonHandler* m_pButtonHandler;           // Button command handler.
    CColorPickerHandler* m_pColorPickerHandler; // Color picker command handler.
};