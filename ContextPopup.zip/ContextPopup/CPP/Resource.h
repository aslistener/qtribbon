// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.

// Used by ContextPopup.rc
#pragma once

#define IDS_APP_TITLE           103
#define IDR_MAINFRAME           128
#define IDI_CONTEXTPOPUP        107
#define IDI_SMALL               108
#define IDS_CONTEXTPOPUP        109
