// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.

// Application.h/cpp implements the IUIApplication interface which is required for any ribbon application.
// This interface contains callbacks made by the ribbon framework to the application
// during various updates like command creation/destruction and view state changes.
//

#pragma once

#include <UIRibbon.h>
#include <propvarutil.h>

#include "CommandHandler.h"
#include "ids.h"

//
//  CLASS: CApplication : IUIApplication
//
//  PURPOSE: Implements interface IUIApplication that defines methods
//           required to manage Framework events.
//
//  COMMENTS:
//
//    CApplication implements the IUIApplication interface which is required for any ribbon application.
//    IUIApplication contains callbacks made by the ribbon framework to the application
//    during various updates like command creation/destruction and view state changes.
//
class CApplication
    : public IUIApplication // Applications must implement IUIApplication.
{
public:

    static HRESULT CreateInstance(CApplication** ppApplication);

    // IUnknown
    IFACEMETHODIMP QueryInterface(REFIID iid, void** ppv);
    IFACEMETHODIMP_(ULONG) AddRef();
    IFACEMETHODIMP_(ULONG) Release();

    // IUIApplication methods.
    STDMETHOD(OnCreateUICommand)(UINT nCmdID,
        UI_COMMANDTYPE typeID,
        IUICommandHandler** ppCommandHandler);

    STDMETHOD(OnViewChanged)(UINT viewId,
    UI_VIEWTYPE typeId,
    IUnknown* pView,
    UI_VIEWVERB verb,
    INT uReasonCode);

    STDMETHOD(OnDestroyUICommand)(UINT32 commandId, 
        UI_COMMANDTYPE typeID,
        IUICommandHandler* commandHandler);

    // Helper functions.
    int GetCurrentContext();

    void SetCurrentContext(int newContext);

private:
    CApplication()
        : m_cRef(1)
        , m_iCurrentContext(IDC_CMD_CONTEXTMAP1)
        , m_pCommandHandler(NULL)
    {
    };

    ~CApplication()
    {
        if (m_pCommandHandler != NULL)
        {
            m_pCommandHandler->Release();
        }
    };

    int m_iCurrentContext;
    CCommandHandler* m_pCommandHandler; // Generic Command Handler.
    ULONG m_cRef;
};
