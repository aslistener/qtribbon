//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HTMLEdit.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDD_FONTDLGBAR               102
#define CG_ID_VIEW_FONTDLGBAR           103
#define ID_FMTBAR_FONTNAME              104
#define ID_FMTBAR_FONTSIZE              105
#define IDC_ADDRCOMBO                   106
#define IDR_MAINFRAME                   128
#define IDR_HTMLEDTYPE                  129
#define IDD_URLDIALOG                   130
#define IDD_INSERT_TABLE                133
#define IDR_MENU1                       136
#define IDR_EDITPOPUP                   136
#define IDC_EDIT                        137
#define ID_Menu                         138
#define ID_TOOLBAR_EDITING              144
#define ID_INDICATOR_VIEW               145
#define IDS_RECENTFILES                 200
#define IDC_EDURL                       1000
#define IDC_FONTNAME                    1001
#define IDC_FONTSIZE                    1002
#define IDC_FONTSTYLE                   1003
#define IDC_EDIT_NUMROWS                1004
#define IDC_EDIT_NUMCOLS                1005
#define IDC_SPIN1                       1006
#define IDC_SPIN2                       1007
#define IDC_EDIT_TABLEATTRIBS           1008
#define IDC_EDIT_CELLATTRIBS            1009
#define IDC_EDIT_CAPTION                1010
#define IDC_EXPLORER                    1013
#define IDC_PHSTATIC                    1014
#define IDC_BTNGO                       1015
#define IDC_BTN_SEARCH                  1017
#define IDC_EDIT_EDITMODE               32771
#define ID_FILE_OPENURL                 32774
#define IDC_EDIT_DESIGNMODE             32775
#define ID_EDIT_SELECTALL               32776
#define ID_EDIT_FONT                    32777
#define ID_EDIT_TEST                    32778
#define ID_TABLE_INSERT                 32779
#define ID_TABLE_INSERTTABLE            32780
#define ID_TABLE_INSERTROW              32781
#define ID_TABLE_INSERTCOLUMN           32782
#define ID_TABLE_DELETEROWS             32783
#define ID_TABLE_DELETECOLUMNS          32784
#define ID_TABLE_MERGECELLS             32785
#define ID_TABLE_SPLITCELL              32786
#define ID_TABLE_INSERTCELL             32787
#define ID_TABLE_DELETECELLS            32788
#define ID_BUTTON_IMAGE                 32791
#define ID_VIEW_EDITINGTOOLBAR          32792
#define ID_FORMAT_SENDTOBACK            32793
#define ID_FORMAT_BRINGTOFRONT          32794
#define ID_FORMAT_SENDBACKWARD          32795
#define ID_FORMAT_BRINGFORWARD          32796
#define ID_FORMAT_SENDBELOWTEXT         32797
#define ID_FORMAT_BRINGABOVETEXT        32798
#define ID_FORMAT_ABSOLUTEPOSITIONELEMENT 32799
#define ID_FORMAT_STATICELEMENT         32800
#define ID_BUTTON_FONTSIZE              32801
#define ID_VIEW_WEB                     32802
#define ID_VIEW_SOURCE                  32803
#define ID_BUTTON_HYPERLINK             32804
#define ID_BUTTON_CENTERJUSTIFY         32805
#define ID_BUTTON_ABSOLUTE              32808
#define ID_BUTTONSTATIC                 32809
#define ID_BUTTON_STATIC                32809
#define ID_BUTTON_BOLD                  32821
#define ID_BUTTON_FONTNAME              32822
#define ID_BUTTON_ITALIC                32825
#define ID_BUTTON_UNDERLINE             32826
#define ID_BUTTON_CENTER                32827
#define ID_BUTTON_LEFTJUSTIFY           32828
#define ID_BUTTON_RIGHTJUSTIFY          32829
#define ID_BUTTON_BULLETLIST            32831
#define ID_BUTTON_OUTDENT               32832
#define ID_BUTTON_INDENT                32833
#define ID_BUTTON_NUMBERLIST            32834
#define ID_BUTTON_COLOR                 32945
#define ID_BUTTON_BLOCKFMT              32946

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
